# octopus-api
![octopus_icon](image.png)
### About
Octopus-api is a python library for performing optimized concurrent requests and API limits set by the endpoint contract. The goal with octopus is to provide the limitations and then use the standard requests library to perform the calls. The tentacles of the octopus are then used to call the endpoint and provide the responses efficiently. 


## Example